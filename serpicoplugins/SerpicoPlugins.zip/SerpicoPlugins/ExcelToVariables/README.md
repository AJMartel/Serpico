# What's this
With this module, you can create UDVs and UDOs from an excel file. This is especially usefull if you wan't to use formula to automatically calculate UDVs, or things like that.

# How

## Here's an exemple of Excel containing UDOs and UDVs

![Template](UDO1.png)

![Template](UDO5.png)

## Upload your Excel

![Template](UDO2.png)

## The UDOs and UDVs are created

![Template](UDO3.png)

![Template](UDO4.png)
