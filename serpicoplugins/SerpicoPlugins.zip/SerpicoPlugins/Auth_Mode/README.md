# WARNING

This plugin disables all authentication and authorization. Be careful enabling it.

## Auth Mode

Auth Mode is a simple plugin to disable authentication and authorization checks. It's purpose is to:
- Provide an example of the power of monkey patching Serpico. See the [blog post](https://www.serpicoproject.com) for more information.
- Speed up development testing

## Installation

1. Upload and enable the plug-in using typical means
2. Create a blank file called "installed" in the directory "./plugins/Auth_Mode"