# Overview

This plugin allows an administrator to add questions that can be filled out by a user. The answers to the question are assigned as a User Defined Variables.

## As an Administrator

Go to Administrator Specific Plugins (https://IP:8443/admin/admin_plugins) > UDV_Worksheet

Add the questions that the user should fill out.

## As a User

1. Create a report
2. Edit Report > Enabled Plugins > UDV_Worksheet
3. Answer the Questions, Save





